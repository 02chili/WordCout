#include <iostream>
#include <fstream>
#include <string>
#include <cctype>

using namespace std;

// ��������
int countCharacters(const string& filename);
int countWords(const string& filename);

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Usage: " << argv[0] << " -c|-w <input_file_name>" << endl;
        return 1;
    }

    string parameter = argv[1];
    string filename = argv[2];

    int result;
    if (parameter == "-c") {
        result = countCharacters(filename);
        cout << "�ַ�����" << result << endl;
    } else if (parameter == "-w") {
        result = countWords(filename);
        cout << "��������" << result << endl;
    } else {
        cerr << "Invalid parameter. Use '-c' for character count or '-w' for word count." << endl;
        return 1;
    }

    return 0;
}

// ͳ���ַ����ĺ���
int countCharacters(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open file: " << filename << endl;
        return -1; // ���ش������
    }

    int count = 0;
    char ch;
    while (file.get(ch)) {
        count++;
    }
    file.close();
    return count;
}

// ͳ�Ƶ������ĺ���
int countWords(const string& filename) {
    ifstream file(filename);
    if (!file.is_open()) {
        cerr << "Failed to open file: " << filename << endl;
        return -1; // ���ش������
    }

    int count = 0;
    bool inWord = false;
    char ch;
    while (file.get(ch)) {
        if (isspace(ch) || ch == ',') {
            if (inWord) {
                inWord = false;
                count++;
            }
        } else {
            inWord = true;
        }
    }
    // ����ļ������Էָ�����β������ҪΪ���һ�����ʼ���
    if (inWord) {
        count++;
    }
    file.close();
    return count;
}
